import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

type Position = 'BTN' | 'SB' | 'BB' | 'UTG' | 'MP' | 'CO';
type Card = {
  rank: string;
  suit: string;
};

const RANKS = ['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2'];
const SUITS = ['♠', '♥', '♦', '♣'];

function getGTOAdvice(position: Position, card1: Card, card2: Card): string {
  const isPaired = card1.rank === card2.rank;
  const isSuited = card1.suit === card2.suit;
  const ranks = [card1.rank, card2.rank].sort((a, b) => 
    RANKS.indexOf(a) - RANKS.indexOf(b)
  );
  
  // Recomendações básicas GTO (simplificadas para estudo)
  if (position === 'BTN' || position === 'CO') {
    if (isPaired && RANKS.indexOf(card1.rank) <= 7) return 'Aumentar 3BB';
    if (ranks[0] === 'A' || ranks[0] === 'K') return 'Aumentar 2.5BB';
    if (isSuited && RANKS.indexOf(ranks[0]) <= 5) return 'Aumentar 2.5BB';
    return 'Desistir';
  }
  
  if (position === 'UTG' || position === 'MP') {
    if (isPaired && RANKS.indexOf(card1.rank) <= 5) return 'Aumentar 3BB';
    if (ranks[0] === 'A' && RANKS.indexOf(ranks[1]) <= 3) return 'Aumentar 3BB';
    if (ranks[0] === 'K' && RANKS.indexOf(ranks[1]) <= 4) return 'Aumentar 2.5BB';
    return 'Desistir';
  }
  
  if (position === 'SB') {
    if (isPaired) return 'Aumentar 3BB';
    if (ranks[0] === 'A' || ranks[0] === 'K') return 'Aumentar 3BB';
    if (isSuited && RANKS.indexOf(ranks[0]) <= 8) return 'Pagar';
    return 'Desistir';
  }
  
  // Posição BB
  if (isPaired) return 'Pagar';
  if (ranks[0] === 'A' || ranks[0] === 'K') return 'Aumentar 3BB';
  if (isSuited && RANKS.indexOf(ranks[0]) <= 9) return 'Pagar';
  return 'Desistir';
}

function App() {
  const [position, setPosition] = useState<Position>('BTN');
  const [card1, setCard1] = useState<Card>({ rank: 'A', suit: '♠' });
  const [card2, setCard2] = useState<Card>({ rank: 'K', suit: '♠' });
  const [showAdvice, setShowAdvice] = useState(false);

  const positions: Position[] = ['BTN', 'SB', 'BB', 'UTG', 'MP', 'CO'];
  const positionDescriptions: Record<Position, string> = {
    'BTN': 'Botão',
    'SB': 'Small Blind',
    'BB': 'Big Blind',
    'UTG': 'Under the Gun',
    'MP': 'Posição Média',
    'CO': 'Cut-off'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">Ferramenta de Estudo GTO Poker</h1>
        
        <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2">Posição na Mesa</label>
            <div className="relative">
              <select
                value={position}
                onChange={(e) => setPosition(e.target.value as Position)}
                className="w-full bg-gray-700 rounded-lg py-2 px-3 appearance-none cursor-pointer"
              >
                {positions.map((pos) => (
                  <option key={pos} value={pos}>{pos} - {positionDescriptions[pos]}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium mb-2">Primeira Carta</label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={card1.rank}
                  onChange={(e) => setCard1({ ...card1, rank: e.target.value })}
                  className="bg-gray-700 rounded-lg py-2 px-3"
                >
                  {RANKS.map((rank) => (
                    <option key={rank} value={rank}>{rank}</option>
                  ))}
                </select>
                <select
                  value={card1.suit}
                  onChange={(e) => setCard1({ ...card1, suit: e.target.value })}
                  className="bg-gray-700 rounded-lg py-2 px-3"
                >
                  {SUITS.map((suit) => (
                    <option key={suit} value={suit}>{suit}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Segunda Carta</label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={card2.rank}
                  onChange={(e) => setCard2({ ...card2, rank: e.target.value })}
                  className="bg-gray-700 rounded-lg py-2 px-3"
                >
                  {RANKS.map((rank) => (
                    <option key={rank} value={rank}>{rank}</option>
                  ))}
                </select>
                <select
                  value={card2.suit}
                  onChange={(e) => setCard2({ ...card2, suit: e.target.value })}
                  className="bg-gray-700 rounded-lg py-2 px-3"
                >
                  {SUITS.map((suit) => (
                    <option key={suit} value={suit}>{suit}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <button
            onClick={() => setShowAdvice(true)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200"
          >
            Obter Recomendação GTO
          </button>

          {showAdvice && (
            <div className="mt-6 p-4 bg-gray-700 rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Recomendação GTO:</h3>
              <p className="text-lg">{getGTOAdvice(position, card1, card2)}</p>
              <div className="mt-4 text-sm text-gray-400">
                <p>Observação: Este é um modelo GTO simplificado apenas para fins de estudo. A estratégia GTO real envolve muito mais variáveis e cálculos complexos.</p>
              </div>
            </div>
          )}
        </div>

        <div className="mt-8 text-center text-sm text-gray-400">
          <p>Esta ferramenta é apenas para fins de estudo. Não use durante jogos reais.</p>
        </div>
      </div>
    </div>
  );
}

export default App;